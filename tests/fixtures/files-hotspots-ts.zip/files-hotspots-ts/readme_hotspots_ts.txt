asap0_id: country id used to uniquely identify the unit in ASAP
name0_shr: short name of the country (max 16 characters)
date: reference date of the hotspot assessment
hs_code: hotspot code
hs_note: hotspot description
comment: narrative by JRC expert that describes the ongoing situation
g1_w_crop: number of Gaul1 units identified by ASAP as crop warnings
g1_w_range: number of Gaul1 units identified by ASAP as rangeland warnings
g1_w_any: number of Gaul1 units identified by ASAP as warnings (crop and/or rangeland)